define( [ "qlik"
],
function ( qlik) {

	return {
		support : {
			snapshot: false,
			export: false,
			exportData : false
		},
		paint: function ($element) {
			//add your rendering code here
			//$element.html( "cui-banner" );
			if (!$("#cui-banner").length) {
				$(".sheet-title-container").after("<div id='cui-banner' style='background: green; color: white; text-transform: uppercase; text-align: center;'>Unclassified//Contorolled Unclassified Information (CUI)</div>");	
			}
			
			//needed for export
			return qlik.Promise.resolve();
		}
	};

} );

